---
name: Bug report / 错误反馈
about: Something ooops happened
title: ''
labels: ''
assignees: ''

---

**Describe the bug 症状是什么？**
A clear and concise description of what the bug is.

**To Reproduce  怎么出现的？**
Steps to reproduce the behavior:


**Expected behavior 本该怎么样？**
A clear and concise description of what you expected to happen.

**Screenshots 截图/报错日志**
If applicable, add screenshots to help explain your problem.


**Additional context 其他信息**
Add any other context about the problem here.
