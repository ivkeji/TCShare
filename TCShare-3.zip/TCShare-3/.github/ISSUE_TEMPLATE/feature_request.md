---
name: Feature request
about: 新功能建议
title: ''
labels: ''
assignees: ''

---

**What feature do you want?**
请清晰描述你想要的功能


**Describe the solution you'd like**
如果可以，请尝试提出可能的解决方案


**Additional context**
其他你想说的
